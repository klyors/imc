let botaoCalcular = document.getElementById("btnCalular");


function calculandoIMC() {
    let peso = document.getElementById("peso").value;
    let altura = document.getElementById("altura").value/100;
    let resultado = document.getElementById("resultado");

    if (altura !== "" && peso !== "") {
        let imc = (peso / (altura * altura)).toFixed(1);
        let mensagem = "";
    
    if (imc < 18.5) {
        mensagem = "Abaixo do Peso";
    } else if (imc < 25) {
        mensagem = "Peso Ideal";
    } else if (imc < 30) {
        mensagem = "Sobrepeso";
    } else if (imc < 35) {
        mensagem = "Obsidade Grau 1";
    } else if (imc < 40) {
        mensagem = "Obsidade Grau 2";
    } else {
        mensagem = "Obsidade Grau 3";
    }

    resultado.textContent = "Seu IMC é: " + imc + " e você esta " + mensagem;

}else {
    resultado.textContent = "Por favor, preencha todos os campos.";}

}

botaoCalcular.addEventListener("click", calculandoIMC);